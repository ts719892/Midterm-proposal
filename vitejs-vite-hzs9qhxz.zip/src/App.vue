<script setup>
import { computed, ref } from 'vue'
import monthly from './data/monthly.json'
import stationData from './data/stations.json'
import MonthlyChart from './components/MonthlyChart.vue'
import StationMap from './components/StationMap.vue'

const selectedMonth = ref(null)
const stationQuery = ref('')
const activeCode = ref('')
const rows = computed(() => selectedMonth.value === null
  ? monthly
  : monthly.filter(d => d.month === selectedMonth.value))
const sum = key => rows.value.reduce((total, row) => total + row[key], 0)
const numbers = computed(() => ({
  total: sum('total'), abnormal: sum('abnormal'), general: sum('general'), major: sum('major'),
}))
const titleMonth = computed(() => selectedMonth.value ? `2025 年 ${selectedMonth.value} 月` : '2025 年全年')
const visibleStations = computed(() => {
  const q = stationQuery.value.trim().toLowerCase()
  return !q ? stationData : stationData.filter(s =>
    s.name.toLowerCase().includes(q) ||
    s.ename.toLowerCase().includes(q) ||
    s.code.includes(q) || s.address.toLowerCase().includes(q))
})
const activeStation = computed(() => stationData.find(s => s.code === activeCode.value))
const highest = computed(() => [...monthly].sort((a,b) => b.total - a.total)[0])
const fmt = n => new Intl.NumberFormat('zh-TW').format(n)
function toggleMonth(month) {
  selectedMonth.value = selectedMonth.value === month ? null : month
}
function reset() { selectedMonth.value = null; stationQuery.value = ''; activeCode.value = '' }
function chooseStation(code) { activeCode.value = code }
</script>

<template>
  <div class="shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-icon">T</div><div><strong>TRA INSIGHT</strong><span>Railway Visual Analytics</span></div></div>
      <div class="sidebar-group">
        <div class="side-label">研究儀表板</div>
        <div class="nav-link selected">▣ <span>事故概覽</span></div>
        <div class="nav-link muted">◉ <span>車站空間分布</span></div>
      </div>
      <div class="sidebar-spacer"></div>
      <div class="sidebar-note">
        <span class="dot"></span> Data quality note
        <p>月度圖表使用官方事故月報的彙整數據；地圖僅顯示車站位置，尚非事故熱點。</p>
      </div>
      <div class="sidebar-bottom">臺鐵事故與異常事件時空視覺化<br/>Vue 3 · D3 · Leaflet</div>
    </aside>

    <main class="main">
      <header class="topbar">
        <div><span class="eyebrow">DATA EXPLORATION / 2025</span><h1>臺鐵事故與異常事件 <em>分析總覽</em></h1>
        <p>以官方月報統計與車站地理資料，探索事件類型與時間分布。</p></div>
        <button class="reset" @click="reset">↻ 重設所有篩選</button>
      </header>

      <div class="filterbar"><div class="filter-label">資料範圍</div>
        <select v-model="selectedMonth" aria-label="選擇月份">
          <option :value="null">2025 年全年</option>
          <option v-for="n in 12" :key="n" :value="n">2025 年 {{ n }} 月</option>
        </select>
        <span class="filter-hint">可點擊下方月份長條圖進行篩選</span>
        <div class="source-pill">● 官方月報（114 年）</div>
      </div>

      <section class="stats-grid">
        <div class="stat stat-primary"><span class="stat-label">{{ titleMonth }} / 事件總數</span><div class="stat-val">{{ fmt(numbers.total) }} <small>件</small></div><div class="stat-sub">事故與行車異常事件合計</div></div>
        <div class="stat"><span class="stat-label"><i class="color-dot teal"></i> 行車異常事件</span><div class="stat-val">{{ fmt(numbers.abnormal) }} <small>件</small></div><div class="stat-sub">類別在官方月報中標示</div></div>
        <div class="stat"><span class="stat-label"><i class="color-dot gold"></i> 一般行車事故</span><div class="stat-val">{{ fmt(numbers.general) }} <small>件</small></div><div class="stat-sub">按官方事故等級彙整</div></div>
        <div class="stat"><span class="stat-label"><i class="color-dot red"></i> 重大行車事故</span><div class="stat-val">{{ fmt(numbers.major) }} <small>件</small></div><div class="stat-sub">按官方事故等級彙整</div></div>
      </section>

      <section class="content-grid">
        <div class="panel chart-panel">
          <div class="panel-head"><div><div class="section-eyebrow">TEMPORAL ANALYSIS</div><h2>每月事故與異常事件趨勢</h2><p>堆疊長條圖 · 2025 年 1–12 月</p></div><span class="panel-tag">D3.js</span></div>
          <div class="legend"><span><i class="color-dot teal"></i>行車異常事件</span><span><i class="color-dot gold"></i>一般行車事故</span><span><i class="color-dot red"></i>重大行車事故</span></div>
          <MonthlyChart :rows="monthly" :selected-month="selectedMonth" @change-month="toggleMonth" />
          <div class="chart-footer"><span>全年最高：<b>{{ highest.month }} 月 / {{ highest.total }} 件</b></span><span>點擊長條可篩選；再點一次取消</span></div>
        </div>

        <div class="panel insight-panel">
          <div class="panel-head"><div><div class="section-eyebrow">DISTRIBUTION</div><h2>事件類型占比</h2><p>{{ titleMonth }}</p></div></div>
          <div class="donut-wrap">
            <div class="css-donut" :style="{'--a': numbers.total ? numbers.abnormal / numbers.total * 100 + '%' : '0%', '--b': numbers.total ? (numbers.abnormal+numbers.general) / numbers.total * 100 + '%' : '0%'}"><div class="donut-center"><b>{{fmt(numbers.total)}}</b><small>總事件數</small></div></div>
          </div>
          <div class="dist-list">
            <div v-for="item in [{ key:'abnormal',name:'行車異常',color:'teal'},{key:'general',name:'一般事故',color:'gold'},{key:'major',name:'重大事故',color:'red'}]" :key="item.key">
              <span><i :class="['color-dot',item.color]"></i>{{item.name}}</span><strong>{{ numbers.total ? (numbers[item.key] / numbers.total * 100).toFixed(1) : 0 }}%</strong>
            </div>
          </div>
        </div>

        <div class="panel map-panel">
          <div class="panel-head"><div><div class="section-eyebrow">GEOSPATIAL DATA</div><h2>臺灣鐵路車站分布圖</h2><p>車站 GPS 點位資料 · 共 {{ stationData.length }} 筆</p></div><span class="panel-tag">Leaflet</span></div>
          <div class="map-content">
            <StationMap :stations="visibleStations" :active-code="activeCode" @choose-station="chooseStation" />
            <div class="station-side">
              <label for="station-search">搜尋車站</label>
              <input id="station-search" v-model="stationQuery" placeholder="輸入站名、車站代碼或縣市" />
              <div class="station-count">符合條件：{{visibleStations.length}} 筆車站</div>
              <div v-if="activeStation" class="selected-station"><span class="side-label">目前選取</span><h3>{{activeStation.name}}站</h3><p>{{activeStation.address}}</p><p>車站代碼：{{activeStation.code}}</p><p>GPS：{{activeStation.lat}}, {{activeStation.lon}}</p><button @click="activeCode = ''">取消選取</button></div>
              <div v-else class="station-placeholder">在地圖上點擊車站，或使用搜尋框尋找車站，就能查看名稱、代碼與 GPS 座標。</div>
              <div class="station-list">
                <button v-for="s in visibleStations.slice(0,8)" :key="s.code" :class="{chosen:s.code===activeCode}" @click="chooseStation(s.code)"><span>{{s.name}}</span><small>{{s.code}}</small></button>
              </div>
            </div>
          </div>
          <div class="map-warning"><strong>重要：</strong>目前地圖只展示車站位置。因尚未將 861 件事件逐筆匹配至車站／區間，不能把車站密集程度解讀為事故熱點；月份篩選也不會改變車站位置。</div>
        </div>
      </section>

      <section class="next-step"><div class="step-icon">↗</div><div><b>下一步：真正的事故熱點分析</b><p>先把 12 份官方 PDF 的逐筆事件整理成 <code>events.json</code>，包含日期、事件等級、車站／站間區間、原因與來源頁碼。完成地理匹配後，才加入 Calendar Heatmap、事故熱點與跨圖表連動。</p></div></section>
      <footer>資料來源：臺鐵 114 年 1–12 月行車事故（件）月報表；使用者提供的車站基本資料集 JSON。地圖圖磚 © OpenStreetMap contributors。</footer>
    </main>
  </div>
</template>
